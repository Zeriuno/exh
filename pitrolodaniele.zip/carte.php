<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta http-equi="Content-Type" content="text/html" charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet">
    <title>Fais ta carte!</title>
  </head>
  <body>
    <main>
      <header>
        <a href="index.html" title="">Accueil</a>
      </header>
    <div>
      <form method="post" action="carte.php">
        <label for="prenom">Prénom:
          <input type="text" name="prenom" placeholder="Victor" required>
        </label>
        <label for="nom">Nom:
          <input type="text" name="nom" placeholder="Hugo" required>
        </label>
        <label for="email"><abbr title="Messagerie électronique en ligne">Mél</abbr>:
          <input type="text" name="email" multiple placeholder="auteur@lalegendedessiecl.es" pattern="([\w*\d*\.*\-*\_*]*)(\+\w*\d*)?@[\w+\.\w+]*" required>
        </label>
        <label for="telephone">Téléphone:
          <input type="text" name="tel" placeholder="+33 1793" pattern="(\+\d{1,2})?[\d+\s*]+">
        </label>
        <button type="submit">C'est bon</button>
      </form>
    </div>
    <div>
      <img src="eg.jpg" alt="" />
    </div>
    <?php
        try{ $pdo = new PDO('mysql:host=localhost;dbname=cartes;charset=utf8', 'root', 'root');
        }
        catch (Exception $e) {
         die('Erreur : ' . $e->getMessage());
        }
        $stmt = $pdo->prepare('INSERT INTO visiteurs(prenom, nom, mel, tel) VALUES(:prenom, :nom, :mel, :tel)');
        $stmt->bindParam(':prenom', $_POST['prenom']);
        $stmt->bindParam(':nom', $_POST['nom']);
        $stmt->bindParam(':mel', $_POST['email']);
        $stmt->bindParam(':tel', $_POST['tel']);
        $stmt->execute();

        $name = $_POST['prenom'];
        $surname = $_POST['nom'];
        $email = $_POST['email'];
        $tel = $_POST['tel'];
        ?>
        <?php
      $font = "Georgia.ttf";
      $img = imagecreatefromjpeg( "eg.jpg" );
      $fg = imagecolorallocate( $img, 255, 0, 0 );
      $left = 30;
      $top = 80;
      $lineheight = 40;

      imagettftext( $img, 30, 0, $left, $top + $lineheight * 0, $fg, $font, $name );
      imagettftext( $img, 35, 0, $left, $top + $lineheight * 1, $fg, $font, $surname );
      imagettftext( $img, 20, 0, $left, $top + $lineheight * 2, $fg, $font, $email );
      imagettftext( $img, 20, 0, $left, $top + $lineheight * 3, $fg, $font, $tel );


      //Output buffering encode in base64
      ob_start();
      imagejpeg( $img );
      $$withphp = ob_get_contents();
      $attachment = chunk_split(base64_encode($withphp));
      ob_clean();

      //mail
      $boundary = md5(date('r', time()));


      $from = "voila@tacarte.fr";
      $to = $email;
      $subject = "Voilà ta carte";
      $headers = "From: {$sender}\r\n"
         . "Reply-To: {$sender}\r\n"
         . "Content-Type: multipart/mixed; boundary=\"PHP-mixed-{$boundary}\"";


         // email body
         $body = <<<EOF
         --PHP-mixed-{$boundary}
         Content-Type: multipart/alternative; boundary="PHP-alt-{$boundary}\"";

         --PHP-alt-{$boundary}
         Content-Type: text/plain; charset="iso-8859-1"
         Content-Transfer-Encoding: 7bit

         Plain text message.
         --PHP-alt-{$boundary}
         Content-Type: text/html; charset="iso-8859-1"
         Content-Transfer-Encoding: 7bit

         <p>HTML message.</p>
         --PHP-alt-{$boundary}--
         --PHP-mixed-{$boundary}
         Content-Type: image/jpeg; name="image.jpg"
         Content-Transfer-Encoding: base64
         Content-Disposition: attachment
         {$attachment}
         --PHP-mixed-{$boundary}--

         EOF;


       $mail_sent = @mail( $to, $subject, $body, $headers );
       if ( $mail_sent == true ) {
            echo 'Email envoyé.';
          } else {
               echo 'Error';
             };
       ?>

  </main>
  </body>
</html>
