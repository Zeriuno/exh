-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Creato il: Feb 26, 2016 alle 03:40
-- Versione del server: 5.5.42
-- Versione PHP: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `cartes`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `visiteurs`
--

CREATE TABLE `visiteurs` (
  `id` int(11) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `mel` varchar(100) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `visiteurs`
--

INSERT INTO `visiteurs` (`id`, `prenom`, `nom`, `mel`, `tel`) VALUES
(1, 'test', 'test', 'test@example.com', '+33111111'),
(25, 'vic', 'tor', 'hu@go', '+123');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `visiteurs`
--
ALTER TABLE `visiteurs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `visiteurs`
--
ALTER TABLE `visiteurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
